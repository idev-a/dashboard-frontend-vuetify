import Vue from 'vue'
import VueWorldMap from 'vue-world-map'

Vue.component('v-world-map', VueWorldMap)
