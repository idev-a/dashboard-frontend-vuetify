// export const BASE_API = 'http://localhost:5000'
export const BASE_API = 'http://35.237.202.17'
